<?php
include "konek_db.php";
$sql=mysql_query("update booking set konfirmasi='sudah' where id='".$_GET['id']."';");
echo "<meta http-equiv='refresh' content='0; url=studio_admin.php' >";

?>