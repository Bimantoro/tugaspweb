<?php
session_start();

if(isset($_SESSION['USR'])){
  echo "<script>alert('Maaf anda Sudah login sebagai member !');</script>";
  echo "<meta http-equiv='refresh' content='0; url=index.php' >";
}
else if(!isset($_SESSION['ADM'])){
  echo "<script>alert('Maaf anda harus Login sebagai Admin terlebih dahulu !');</script>";
  echo "<meta http-equiv='refresh' content='0; url=admin_login.php' >";
}else{

?>

<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="asset/icon.png"/>
  <title>Tambah Admin Baru</title>
  <meta name="viewport" content="width=device-width , user-scalable=no">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/escape.css">
  <link href="datepicker/css/jquery.datepick.css" rel="stylesheet">
        <script src="js/jquery2.js"></script>     
        <script>

         function validasi_nomer(n){
          var numbers =/^[0-9]+$/;
          if(!n.match(numbers)){
            reg.cek.value=reg.cek.value.substr(0,reg.cek.value.length-1);
            
          }else{
              
          }

         }

        </script>

</head>
<body>
<br>
<div class="container">
  <nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index.php"><img src="asset/logos.png" class="img-responsive" alt="Escape Studio" style="max-width: 65px; height: auto; "></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="admin_dash.php">Dashboard <span class="sr-only">(current)</span></a></li>
        <li><a href="management_admin.php">Management Admin</a></li>
        <li class="active"><a href="tambah_admin.php">Tambah Admin Baru</a></li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> <?php echo "".$_SESSION['ADM']; ?>
          <span class="caret"></span></a>
          <ul class="dropdown-menu" >
            <li><a href="logout.php">Logout</a></li> 
          </ul>
        </li
        
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="content">


      <!-- / masukkan isi web disini -->
      <div class="container" style="margin-top: 5%;" align="center">
          <h2 style="text-align: center;">TAMBAH ADMIN BARU</h2>
         
            <form id="reg" name="register" style="width: 100%;" action="#" method="post">
                <div class="container" style="max-width: 600px;text-align: left; padding-top: 2%;">
                  <div class="content">
                  <div class="form-group"> 
                          <?php
                          $peringatan='';
                          include "konek_db.php";
                          if($_POST['admin_id']!='' or $_POST['pass']!='' or $_POST['nama']!='' or $_POST['nomer']!=''){
                              if($_POST['verifikasi']!=$_SESSION['vercode']){
                                $peringatan.="captcha yang anda masukkan salah !";
                              }else{
                                $admin=$_POST['admin_id'];
                                $pass=$_POST['pass'];
                                $nama=$_POST['nama'];
                                $mail=$_POST['mail'];
                                $nomer=$_POST['nomer'];
                                $cek_email=mysql_query("select * from admin where email='".$mail."'");

                                $ada=mysql_num_rows($cek_email);
                                if($ada==NULL){

                                $sql=mysql_query("insert into admin value('".$admin."','".$pass."', '".$nama."','".$mail."','".$nomer."')");
                                if($sql){
                                      
                                      echo "<meta http-equiv='refresh' content='0; url=member_login.php' >";
                                      echo "<script>alert('berhasil disimpan');</script>";
                                    }
                                    else{
                                      $peringatan.= "admin id '".$admin."' tidak tersedia !";
                                  }
                                      
                              }else{
                                $peringatan.= "email yang anda masukkan sudah digunakan !";
                              }
                            }
                          }


                          ?>
                    <p style="color: red; text-align: center;" ><?php echo "".$peringatan;?></p>
                  </div>
                  <div class="form-group" > 
                    <label>Admin ID : <span style="color: red;">*</span></label>
                    <input type="text" class="form-control" maxlength="10" name="admin_id" required> 
                  </div>
                  <div class="form-group"> 
                    <label>Password : <span style="color: red;">*</span></label>
                    <input type="password" class="form-control" maxlength="10" name="pass" id="pass" required>
                  </div>
                  <div class="form-group"> 
                    <label>Nama Admin baru : <span style="color: red;">*</span></label>
                    <input type="text" class="form-control" name="nama" required> 
                  </div>
                  <div class="form-group"> 
                    <label>Email : <span style="color: red;">*</span></label>
                    <input type="email" class="form-control" name="mail" required> 
                  </div>
                  
                  <div class="form-group"> 
                    <label>No. Hp :</label>
                    <input type="text" class="form-control" name="nomer" id="cek" onkeyup="validasi_nomer(this.value)">
                  </div>

                  <div class="form-group" align="center">
                    <div><img src="captcha.php" style="min-width: 100px;"></div>
     
                  </div>

                  <div class="form-group">
                    <label>masukkan angka diatas : </label>
                    <input type="text" class="form-control" name="verifikasi" required>
                    <label style="color: red;"></label>
                  </div>
                  

                  <div align="center">
                  <input type="submit" class="btn btn-success" value="Daftar">
                  <input type="reset" class="btn btn-primary" value="Reset">
                  <a href="management_admin.php" class="btn btn-danger">Batal</a>
                  </div>
                </div>
            
            </form>
            
          
   
      </div>

  
</div>

<div class="footer">
  <div class="container">
    &copy; Created by Danang  Aji Bimantoro
  </div>
</div>

  
</div>



  <script src="js/bootstrap.min.js"></script>

  
</body>
</html>

<?php
  }

?>