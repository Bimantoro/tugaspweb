<?php
 
/*
membuat captcha dengan php
*/
 
session_start();
$text = rand(1000000,9999999);
$_SESSION["vercode"] = $text;
$height = 40;
$width = 150;
 
$image_p = imagecreate($width, $height);
$black = imagecolorallocate($image_p, 0, 0, 0);
$white = imagecolorallocate($image_p, 255, 255, 255);
$font_size = 18;
 
imagestring($image_p, $font_size, 39, 12, $text, $white);
imagejpeg($image_p, null, 100);
 
?>