<?php
	include "konek_db.php";
	session_start();
	$sql=mysql_query("select * from booking where id='".$_GET['id']."'");
	$isi=mysql_fetch_array($sql); 
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body onload="window.print()">
	<div align="center">
		<img src="asset/esc.png" style="width: 30%; height: auto; ">
	</div>
	<br>
	<div style="border:solid 1px black; border-radius: 25px;">
	<div align="center">
		<p style="text-align: center;">Ini adalah bukti otentik, pembookingan studio music escape <br>
		harap bukti ini dibawa saat akan main di escape studio<br>
		#terimakasih</p>
	</div>
	<table style="width: 100%;">
		<tr>
			<td align="right">Nama :</td>
			<td><?php echo $_SESSION['USR']; ?></td>
		</tr>
		<tr>
			<td align="right">Contact :</td>
			<td><?php echo $isi['no_hp']; ?></td>
		</tr>
		<tr>
			<td align="right">Alamat :</td>
			<td><?php echo $isi['alamat']; ?></td>
		</tr>
		<tr>
			<td align="right">Shift :</td>
			<td><?php echo $isi['shift']; ?></td>
		</tr>
		<tr>
			<td align="right">Tanggal main :</td>
			<td><?php echo $isi['tgl_main']; ?></td>
		</tr>
		
	</table>
	<br>
	</div>

	
</body>
</html>