<?php
session_start();

if(isset($_SESSION['USR'])){
  echo "<script>alert('Maaf anda Sudah login sebagai member !');</script>";
  echo "<meta http-equiv='refresh' content='0; url=index.php' >";
}
else if(!isset($_SESSION['ADM'])){
  echo "<script>alert('Maaf anda harus Login sebagai Admin terlebih dahulu !');</script>";
  echo "<meta http-equiv='refresh' content='0; url=admin_login.php' >";
}else{

?>

<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="asset/icon.png"/>
	<title>Manage Our Music Studio !</title>

	<meta name="viewport" content="width=device-width , user-scalable=no">

	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/escape.css">
	
</head>
<body>
<br>
<div class="container">
	<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index.php"><img src="asset/logos.png" class="img-responsive" alt="Escape Studio" style="max-width: 65px; height: auto; "></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li ><a href="admin_dash.php">Dashboard <span class="sr-only">(current)</span></a></li>
        <li class="active"><a href="manage_member.php">Management Studio</a></li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> <?php echo "".$_SESSION['ADM']; ?>
          <span class="caret"></span></a>
          <ul class="dropdown-menu" >
            <li><a href="logout.php">Logout</a></li> 
          </ul>
        </li
        
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="content">
 
      <?php
        include "konek_db.php";
        $peringatan='';
        $sql=mysql_query("select * from booking;");
        $jmlh=mysql_num_rows($sql);

        $sql2=mysql_query("select * from booking where datediff(current_date(), tgl_main)=0;");
        $jmlh2=mysql_num_rows($sql2);

        $query=mysql_query("select * from penyewaan;");
        $jumlah_sewa=mysql_num_rows($query);

      ?>
      <div class="jumbotron" style="background: #eee; margin-top: 5%;">
        <div>
          <h1>Management Studio Music</h1>
          <p>Ini adalah halaman untuk melakukan management Studio Music, anda dapat melihat siapa saja member yang melakukan booking studio, membatalkan pembookingan, menyetujui pembookingan, mengisi formulir sewa offline, menambahkan denda jika terjadi kerusakan.
          mohon gunakan fitur ini dengan bijak</p>
          <p>Terima kasih #Owner</p>
          </div>
      </div>

      <br>
      <p>Jumlah data pembookingan yang main hari ini : <?php echo "".$jmlh2; ?></p>
      <?php
      if($jmlh==NULL){
        ?>

          <br><br>
          <h4 style="text-align: center; text-decoration: bold; color: red;">TIDAK ADA PEMBOOKINGAN YANG MAIN HARI INI</h4>


      <?php
      }else{
        ?>
        <div class="table-responsive">
          <table class="table table-striped table-condensed table-hover" align="center" style="text-align: center;">
          <tr style="background-color: #222; color: white;">
              <th style="text-align: center; max-width: 600px;">Username</th>
              <th style="text-align: center;">Nama</th>
              <th style="text-align: center;">Contact Person</th>
              <th style="text-align: center;">Tanggal Main</th>
              <th style="text-align: center;">Shift</th>
              <th style="text-align: center;">Konfirmasi</th>
              <th style="text-align: center;">Tanggal Booking</th>
              <th style="text-align: center;">Aksi</th>

          </tr>
          <?php while($isi2=mysql_fetch_array($sql2)) { 
                $tm2=$isi2['tgl_main'];
                $tm2=explode('-', $tm2);
                $tm2=$tm2[2].'/'.$tm2[1].'/'.$tm2[0];
            ?>
          <tr>
              <td><?php echo $isi2['username']; ?></td>
              <td><?php echo $isi2['nama']; ?></td>
              <td><?php echo $isi2['no_hp']; ?></td>
              <td><?php echo $tm2; ?></td>
              <td><?php echo $isi2['shift']; ?></td>
              <td><?php echo $isi2['konfirmasi']; ?></td>
              <td><?php echo $isi2['tgl_booking'] ?></td>
              <td align="center">
                <?php if($isi2['konfirmasi']=='belum'){ ?>
                <a class="btn btn-success btn-sm" href="konfirmasi_booking.php?id=<?php echo $isi2['id']; ?>">Konfirm</a>
                <a class="btn btn-danger btn-sm" href="batalkan_pembookingan.php?id=<?php echo $isi2['id']; ?>" onClick="return confirm('apakah anda yakin akan membatalkan pembookingan ini ?')">Batal</a>
                <?php }else{
                  ?>
                  <a class="btn btn-success btn-sm" href="booking_ke_sewa.php?id=<?php echo $isi2['id']; ?>">Main</a>
                  <?php
                  } ?>
              </td>
          </tr>
          <?php } ?>
          </table>
        </div>

        <div class="garis"></div>

     <?php   
      }
      ?>
      <br><br>


      <br>
      <p>Jumlah data pembookingan saat ini : <?php echo "".$jmlh; ?></p>
      <?php
      if($jmlh==NULL){
        ?>

          <br><br>
          <h4 style="text-align: center; text-decoration: bold; color: red;">TIDAK ADA PEMBOOKINGAN SAAT INI</h4>


      <?php
      }else{
        ?>
        <div class="table-responsive">
          <table class="table table-striped table-condensed table-hover" align="center" style="text-align: center;">
          <tr style="background-color: #222; color: white;">
              <th style="text-align: center; max-width: 600px;">Username</th>
              <th style="text-align: center;">Nama</th>
              <th style="text-align: center;">Contact Person</th>
              <th style="text-align: center;">Tanggal Main</th>
              <th style="text-align: center;">Shift</th>
              <th style="text-align: center;">Konfirmasi</th>
              <th style="text-align: center;">Tanggal Booking</th>
              <th style="text-align: center;">Aksi</th>

          </tr>
          <?php while($isi=mysql_fetch_array($sql)) { 
                $tm=$isi['tgl_main'];
                $tm=explode('-', $tm);
                $tm=$tm[2].'/'.$tm[1].'/'.$tm[0];
            ?>
          <tr>
              <td><?php echo $isi['username']; ?></td>
              <td><?php echo $isi['nama']; ?></td>
              <td><?php echo $isi['no_hp']; ?></td>
              <td><?php echo $tm; ?></td>
              <td><?php echo $isi['shift']; ?></td>
              <td><?php echo $isi['konfirmasi']; ?></td>
              <td><?php echo $isi['tgl_booking'] ?></td>
              <td align="center">
                <?php if($isi['konfirmasi']=='belum'){ ?>
                <a class="btn btn-success btn-sm" href="konfirmasi_booking.php?id=<?php echo $isi['id']; ?>">Konfirm</a>
                <a class="btn btn-danger btn-sm" href="batalkan_pembookingan.php?id=<?php echo $isi['id']; ?>" onClick="return confirm('apakah anda yakin akan membatalkan pembookingan ini ?')">Batal</a>
                <?php }else{
                  ?>
                  <a class="btn btn-success btn-sm" href="booking_ke_sewa.php?id=<?php echo $isi['id']; ?>">Main</a>
                  <?php
                  } ?>
              </td>
          </tr>
          <?php } ?>
          </table>
        </div>

     <?php   
      }
      ?>
      <br><br>
      <div align="right">
        <a class="btn btn-default" href="cetak_data_booking.php" target="_blank">Cetak Laporan Pembookingan</a>
      </div>
      <br>
      <div class="garis"></div>
      <br>
      <p>Jumlah data penyewaan saat ini : <?php echo "".$jumlah_sewa; ?></p>
      <?php
      if($jumlah_sewa==NULL){
        ?>

          <br><br>
          <h4 style="text-align: center; text-decoration: bold; color: red;">TIDAK ADA PENYEWAAN SAAT INI</h4>


      <?php
      }else{
        $total_uang_masuk=0;
        ?>
        <div class="table-responsive">
          <table class="table table-striped table-condensed table-hover" align="center" style="text-align: center;">
          <tr style="background-color: #222; color: white;">
              <th style="text-align: center;">Nama</th>
              <th style="text-align: center;">Contact Person</th>
              <th style="text-align: center;">Tanggal Main</th>
              <th style="text-align: center;">Shift</th>
              <th style="text-align: center;">Biaya/shift</th>
              <th style="text-align: center;">Denda</th>
              <th style="text-align: center;">Total Bayar</th>
              <th style="text-align: center;">Aksi</th>

          </tr>
          <?php while($data=mysql_fetch_array($query)) { 
                $tma=$data['tgl_main'];
                $tma=explode('-', $tma);
                $tma=$tma[2].'/'.$tma[1].'/'.$tma[0];

                
            ?>
          <tr>
              <td><?php echo $data['nama']; ?></td>
              <td><?php echo $data['no_hp']; ?></td>
              <td><?php echo $tma; ?></td>
              <td><?php echo $data['shift']; ?></td>
              <td><?php echo $data['biaya']; ?></td>
              <td><?php echo $data['denda']; ?></td>
              <td><?php echo $data['total_bayar'];  $total_uang_masuk=$total_uang_masuk+$data['total_bayar'];?></td>
              <td align="center">
                <a href="tambah_denda.php?id=<?php echo $data['id']; ?>" class="btn btn-primary btn-sm">Tambah Denda</a>
              </td>
          </tr>
          <?php } ?>
          </table>
        </div>

     <?php   
      }
      ?>

      <br><br>
      <div align="left">
      <p>Jumlah keseluruhan pemasukan : <b><?php echo $total_uang_masuk; ?></b></p>
      </div>
      <div align="right">
        <a class="btn btn-success" href="update_studio.php">Update Studio</a>
        <a class="btn btn-primary" href="booking_offline.php">Booking offline</a>
        <a class="btn btn-primary" href="sewa_offline.php">Sewa</a>
        <a class="btn btn-default" href="cetak_data_penyewaan.php" target="_blank">Cetak Laporan Penyewaan</a>
      </div>

      

	
</div>


<div class="footer">
	<div class="container">
		&copy; Created by Danang  Aji Bimantoro
	</div>
</div>
	
</div>
	<script src="js/jquery2.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>

<?php
	}
?>