<?php
  session_start();
  include "konek_db.php";
  if(!session_is_registered('ADM')){
    echo "<script>alert('Ooopss .. anda harus login terlebih dahulu');</script>";
    echo "<meta http-equiv='refresh' content='0; url=member_login.php' >";
  }
  if(!isset($_SESSION['ADM'])){
    echo "<script>alert('Ooopss .. anda harus login terlebih dahulu');</script>";
    echo "<meta http-equiv='refresh' content='0; url=member_login.php' >";
  }else{

  	$tgl=date("Y-m-d");
  	$tanggal_main=date("d/m/Y");
  	$ambil_harga=mysql_query("select tarif_sewa_studio from alat where nama='studio'");
  	$ambil_data=mysql_fetch_array($ambil_harga);

  	if($_POST['nama']!=''){
  		$nama=$_POST['nama'];
  		$nomer=$_POST['nomer'];
  		$alamat=$_POST['alamat'];
  		$biaya=$ambil_data['tarif_sewa_studio'];
  		$shift=$_POST['shift'];
  		$denda=0;
  		$total_bayar=$biaya+$denda;

  		$sql=mysql_query("insert into penyewaan value('', '".$nama."', '".$nomer."', '".$alamat."', '".$tgl."', '".$shift."', '".$biaya."', '".$denda."', '".$total_bayar."')");

  		echo "<meta http-equiv='refresh' content='0; url=studio_admin.php'>";
  	}

?>
<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" href="asset/icon.png"/>
	<title>Tempat sewa studio Music</title>
  <meta name="viewport" content="width=device-width , user-scalable=no">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/escape.css">
	<link href="datepicker/css/jquery.datepick.css" rel="stylesheet">
	<script src="js/jquery2.js"></script>
	<script type="text/javascript">

        function pilih_shift(shift){
        		form_booking.shift.value=shift;
        }

        function validasi_nomer(n){
          var numbers =/^[0-9]+$/;
          if(!n.match(numbers)){
            form_booking.nomer.value=form_booking.nomer.value.substr(0,form_booking.nomer.value.length-1);
            
          }else{
              
          }

         }

        function enable_submit(){
        	if(form_booking.submit_booking.disabled==true){
        	form_booking.submit_booking.disabled=false;
        }else{
        	form_booking.submit_booking.disabled=true;
        }
        }

    </script>
</head>
<body>
<br>
<div class="container">
	<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index.php"><img src="asset/logos.png" class="img-responsive" alt="Escape Studio" style="max-width: 65px; height: auto; "></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li ><a href="admin_dash.php">Dashboard <span class="sr-only">(current)</span></a></li>
        <li ><a href="studio_admin.php">Music Studio</a></li>
        <li class="active"><a href="sewa_offline.php">Penyewaan</a></li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> <?php echo "".$_SESSION['ADM']; ?>
          <span class="caret"></span></a>
          <ul class="dropdown-menu" >
            <li><a href="logout.php">Logout</a></li> 
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="content">


			<!-- / masukkan isi web disini -->

			<div class="jumbotron" style="background: #eee; margin-top: 5%;">
  				<h1 style="text-align: center;">Formulir Penyewaan Studio Music</h1>
  				<p style="text-align: center;">Silahkan isi Form Penyewaan dibawah ini !</p>
  					<form  method="post" id="form_booking" action="#">
  					
		                  <div class="form-group"> 
		                    <label>Nama :</label>
		                    <input type="text" class="form-control" name="nama" placeholder="masukkan nama disini"> 
		                  </div>
		                  <div class="form-group"> 
		                    <label>No Hp :</label>
		                    <input type="text" class="form-control" name="nomer" id="nomer" placeholder="masukkan nomer hp disini" onkeyup="validasi_nomer(this.value)"> 
		                  </div>
		                  <div class="form-group"> 
		                    <label>Alamat :</label>
		                    <input type="text" class="form-control" name="alamat" placeholder="masukkan alamat disini"> 
		                  </div>
		                  
		                  <div class="form-group">
		                  	
		                  	<label>Tanggal Main :</label>
		                 
		                  	<div class="row">
		   						<div class="col-md-5">
		                  			<input class="form-control" type="text" name="date" readonly required id="tanggal" style="200px;" value="<?php echo $tanggal_main; ?>">
		                  		</div>

		                  	</div> 

		                    
		                  </div>
		                  
		                  <div class="form-group"> 
		                    <label>Shift :</label>
		                    <input type="text" class="form-control" name="shift" readonly> 
		                    <br>
		                    <div class="table-responsive">
					          <table class="table table-striped table-condensed table-hover" align="center" style="text-align: center;">
					          <tr style="background-color: #222; color: white;">
					              <th style="text-align: center;">Shift</th>
					              <th style="text-align: center;">Waktu Main (mulai)</th>
					              <th style="text-align: center;">Waktu Main (selesai)</th>
					              <th style="text-align: center;">Aksi</th>

					          </tr>

					          <?php 
					          
					          	$jam_mulai=8;	
					          	
					          for($index=1;$index<16;$index++) {
					          		
					           ?>
					          <tr>
					              <td><?php echo $index; ?></td>
					              <td><?php 
					              	if($jam_mulai<10){
					              echo "0"; echo $jam_mulai; echo ":00";
					              }else{
					              		echo $jam_mulai; echo ":00";
					              	} ?></td>

					              <td>
					              <?php 
					              	if($jam_mulai+1<10){
					              echo "0"; echo $jam_mulai+1; echo ":00";
					              }else{
					              		echo $jam_mulai+1; echo ":00";
					              	} ?>
					              </td>

					              <td>
					              		<?php 
					              		
					              		$temp=0;
					              		$coba=mysql_query("select * from penyewaan where tgl_main='".$tgl."'");
					              		$jmdata=mysql_num_rows($coba);
					              		if($jmdata==0){
					              			?>
					              			<input type="button" value="Bisa disewa" class="btn btn-success" onclick="pilih_shift(<?php echo $index; ?>)">
					              			<?php
					              		}else{
					              			while ($isi=mysql_fetch_array($coba)) {
					              		 	# code...
					              		 	if($index==$isi['shift']){
					              		 		$temp.=1;
					              		 	}
					              		 }
					              		 	if($temp==1){
					              		 		?>
					              		 		<input type="button" value="Sudah disewa" class="btn btn-danger" disabled>
					              			 <?php		
					              		 	}else{
					              		 		?>

					              		 		<input type="button" value="Bisa disewa" class="btn btn-success" onclick="pilih_shift(<?php echo $index; ?>)">
					              		 		<?php
					              		 	}
					              		 
					              		 }
					              		  ?>
					              </td>
					          </tr>
					          <?php 
					          		$jam_mulai++;
					          }
					           ?>
					          </table>
					        </div>


					        <div class="form-group">
					        	<input type="checkbox" name="agreement" id="agreement" onchange="enable_submit()">  Data yang saya masukkan sudah benar
					        </div>

		                  </div>

		                  	<input type="submit" value="Sewa Studio" class="btn btn-primary" disabled id="submit_booking">
		                  	<a href="studio_admin.php" class="btn btn-primary">Cancel</a>
  					</form>
  				
			</div>

	
</div>


<div class="footer">
	<div class="container">
		&copy; Created by Danang  Aji Bimantoro
	</div>
</div>
	
</div>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>

<?php
  }

?>