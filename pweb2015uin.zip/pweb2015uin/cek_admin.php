<?php

include "konek_db.php";

$admin_id=$_POST['admin_id'];
$pass=$_POST['pass_id'];

$sql=mysql_query("select pass_id from admin where admin_id='".$admin_id."'");
$jml=mysql_num_rows($sql);
if($jml==NULL){
	echo "<script>alert(' $admin_id belum terdaftar sebagai admin !');</script>";
	echo "<meta http-equiv='refresh' content='0; url=admin_login.php' >";
}else{

	while($data=mysql_fetch_array($sql)) {

	if($pass==$data['pass_id']){
		echo "<meta http-equiv='refresh' content='0; url=admin_dash.php' >";
	}else{
		echo "<script>alert('kombinasi admin_id dan password salah !');</script>";
		echo "<meta http-equiv='refresh' content='0; url=admin_login.php' >";
	}
}
}

?>