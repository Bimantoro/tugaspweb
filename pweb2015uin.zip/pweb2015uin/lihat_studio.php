<?php
        session_start();
        include "konek_db.php";
        if(!isset($_SESSION['USR'])){
            echo "<script>alert('maaf, anda harus login terlebih dahulu sebagai member')";
            echo "<meta http-equiv='refresh' content='0; url=member_login.php' >";
          }else{


          
          ?>
<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="asset/icon.png"/>
  <title>Selamat datang di escape studio</title>

  <meta name="viewport" content="width=device-width , user-scalable=no">

  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/escape.css">
  
</head>
<body>
<br>
<div class="container">
  <nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index.php"><img src="asset/logos.png" class="img-responsive" alt="Escape Studio" style="max-width: 65px; height: auto; "></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
        <li class="active"><a href="lihat_studio.php">Escape Music Studio</a></li>
        <li><a href="booking.php">Booking</a></li>
        <li><a href="cetak_bookingan.php">Status Pembookingan</a></li>
      </ul>

          <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> <?php echo "".$_SESSION['USR']; ?>
          <span class="caret"></span></a>
          <ul class="dropdown-menu" >
            <li><a href="logout.php">Logout</a></li> 
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="content">
    <?php $sql=mysql_query("select gambar, deskripsi from alat where nama='studio'");
          $query=mysql_query("select nama, gambar, deskripsi from alat where level='member'");
          $data=mysql_fetch_array($sql);
     ?>
              <div class="jumbotron" style="margin-top: 5%;">
                  <h3 style="text-align: center;"><b>Selamat Datang Di Escape Studio Music</b></h3>
                  <img src="asset/uploads/<?php echo $data['gambar']; ?>" class="img-responsive" >
                  <br>
                  <p><?php echo $data['deskripsi']; ?></p>
                
              </div>
          <?php while($isi=mysql_fetch_array($query)){ ?>
              <div class="jumbotron">
                    <h3 style="text-align: center;"><b><?php echo $isi['nama']; ?></b></h3>
                    <img src="asset/uploads/<?php echo $isi['gambar']; ?>" style="width: 100%; height: auto;">
                    <br>
                    <br>
                    <p><?php echo $isi['deskripsi']; ?></p>
               </div>
               <?php } ?>





</div>

  
</div>
<div class="footer">
  <div class="container">
    &copy; Created by Danang  Aji Bimantoro
  </div>
</div>

</div>



  <script src="js/jquery2.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>

<?php } ?>
