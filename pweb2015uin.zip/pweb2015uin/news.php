
<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="asset/icon.png"/>
  <title>Selamat datang di escape news</title>

  <meta name="viewport" content="width=device-width , user-scalable=no">

  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/escape.css">
  
</head>
<body>
<br>
<div class="container">
  <nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index.php"><img src="asset/logos.png" class="img-responsive" alt="Escape Studio" style="max-width: 65px; height: auto; "></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
        <li class="active"><a href="news.php">Music News</a></li>
      </ul>
      <?php
        session_start();

        if(isset($_SESSION['USR'])){
          ?>
          <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> <?php echo "".$_SESSION['USR']; ?>
          <span class="caret"></span></a>
          <ul class="dropdown-menu" >
            <li><a href="logout.php">Logout</a></li> 
          </ul>
        </li>
      </ul>
      <?php
        }
        else {
      ?>
      <ul class="nav navbar-nav navbar-right">
        <li><a href=""><span class="glyphicon glyphicon-user"></span> Register</a></li>
        <li><a href="member_login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>
      <?php
    }
    ?>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="content">


      <!-- / masukkan isi web disini -->
      
      <div class="jumbotron" style="background: #fff000 url(asset/news_yellow.png) no-repeat center; margin-top: 5%;">
          <h1><marquee>Selamat Datang di Escape Music News</marquee></h1>
          <p>Escape Studio memberikan berita-berita terbaru yang dapat anda akses kapanpun dan dimanapun tanpa ada batasan, berita-berita tentang music akan selalu di update</p>
      </div

      <?php 
        include "konek_db.php";
        $sql=mysql_query("select * from news ORDER BY created DESC;");
        $jmlh=mysql_num_rows($sql);
        if($jmlh==NULL){
          ?>

          <br>
          <br>
          <p style="color: red; text-align: center;">Tidak ada post untuk ditampilkan !</p>

          <?php
        }else{
          ?>

          <br>
          <?php 
              while($isi=mysql_fetch_array($sql)){
                ?>

                  <div class="jumbotron" id="teks">
                    <h2><?php echo $isi['judul']; ?></h2>
                    <p><small>Diposting Oleh : <b><?php echo $isi['admin']; ?></b> pada : <i><small><?php echo $isi['created']; ?></small></i></small></p>
                    <div class="img-responsive">
                    <p><?php echo $isi['isi']; ?></p>
                    </div>
                  </div>

                <?php
              }
           ?>


          <?php
        }
      ?>


  
</div>

  
</div>
<div class="footer">
  <div class="container">
    &copy; Created by Danang  Aji Bimantoro
  </div>
</div>

</div>



  <script src="js/jquery2.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>
