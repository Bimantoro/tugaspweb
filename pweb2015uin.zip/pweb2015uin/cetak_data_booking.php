<!DOCTYPE html>
<html>
<head>
	<title></title>
	
</head>
<body onload="window.print()">
<?php
	include "konek_db.php";
	$sql=mysql_query("select * from booking");
 ?>
 <div align="center">
		<p style="text-align: center;">Ini adalah data pembookingan yang dilakukan: <br></p>
	</div>
 <div align="center">
 	 <table style="width: 100%;" align="center">
 	 <tr>
 		<th style="text-align: center; max-width: 600px;">Username</th>
              <th style="text-align: center;">Nama</th>
              <th style="text-align: center;">Contact Person</th>
              <th style="text-align: center;">Tanggal Main</th>
              <th style="text-align: center;">Shift</th>
              <th style="text-align: center;">Konfirmasi</th>
              <th style="text-align: center;">Tanggal Booking</th>
	</tr>
	<?php while($isi=mysql_fetch_array($sql)){
		$tm=$isi['tgl_main'];
                $tm=explode('-', $tm);
                $tm=$tm[2].'/'.$tm[1].'/'.$tm[0];
	 ?>
	<tr>
			<td style="text-align: center;"><?php echo $isi['username']; ?></td>
            <td style="text-align: center;"><?php echo $isi['nama']; ?></td>
            <td style="text-align: center;"><?php echo $isi['no_hp']; ?></td>
            <td style="text-align: center;"><?php echo $tm; ?></td>
            <td style="text-align: center;"><?php echo $isi['shift']; ?></td>
            <td style="text-align: center;"><?php echo $isi['konfirmasi']; ?></td>
            <td style="text-align: center;"><?php echo $isi['tgl_booking'] ?></td>
	</tr>
	<?php } ?>

	 </table>
 </div>

</body>
</html>