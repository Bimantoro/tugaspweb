<?php
session_start();
include "konek_db.php";
if(isset($_SESSION['USR'])){
  echo "<script>alert('Maaf anda Sudah login sebagai member !');</script>";
  echo "<meta http-equiv='refresh' content='0; url=index.php' >";
}
else if(!isset($_SESSION['ADM'])){
  echo "<script>alert('Maaf anda harus Login sebagai Admin terlebih dahulu !');</script>";
  echo "<meta http-equiv='refresh' content='0; url=admin_login.php' >";
}else{

  $peringatan='';

  $sql=mysql_query("select tarif_sewa_studio from alat where nama='studio'");
  $data=mysql_fetch_array($sql);
  $harga_sewa=$data['tarif_sewa_studio'];

  $sql=mysql_query("select denda from alat where nama='denda_gitar'");
  $data=mysql_fetch_array($sql);
  $denda_gitar=$data['denda'];

  $sql=mysql_query("select denda from alat where nama='denda_bass'");
  $data=mysql_fetch_array($sql);
  $denda_bass=$data['denda'];

  $sql=mysql_query("select denda from alat where nama='denda_drum'");
  $data=mysql_fetch_array($sql);
  $denda_drum=$data['denda'];






  if(isset($_GET['action'])){
    if($_GET['action']=='harga'){
        $update_tarif=mysql_query("update alat set tarif_sewa_studio='".$_POST['harga']."' where nama='studio'");
        $update_tarif=mysql_query("update alat set denda='".$_POST['gitar']."' where nama='denda_gitar'");
        $update_tarif=mysql_query("update alat set denda='".$_POST['bass']."' where nama='denda_bass'");
        $update_tarif=mysql_query("update alat set denda='".$_POST['drum']."' where nama='denda_drum'");
        echo "<meta http-equiv='refresh' content='0; url=update_studio.php'>";

    }else if($_GET['action']=='upload'){
      $target_dir = "asset/uploads/";
      $target_file = $target_dir . basename($_FILES["gambar"]["name"]);
      $uploadOk = 1;
      $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

      
      $check = getimagesize($_FILES["gambar"]["tmp_name"]);
      if($check !== false) {
              $uploadOk = 1;
          } else {
              $peringatan="maaf yang anda pilih bukan gambar :-(";
              $uploadOk = 0;
          }
      

      if ($_FILES["gambar"]["size"] > 2000000) {
          $peringatan='ukuran gambar terlalu besar pilih gambar dengan ukuran kurang 2 MB';
          $uploadOk = 0;
      }

      if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
      && $imageFileType != "gif" ) {
          $peringatan='pilih gambar dengan format JPG, PNG, JPEG atau GIF';
          $uploadOk = 0;
      }

      if ($uploadOk == 0) {
          
      } else {
          if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file)) {
              $nama_file=$_FILES['gambar']['name'];
          } else {
              echo "<script>alert('gambar tidak terupload ke server'); </script>";
              echo "<meta http-equiv='refresh' content='0; url=update_studio.php'>";
              
          }
      }
    }else if($_GET['action']=='simpan'){
      $gambar=$_POST['gambar_alat'];
      $nama_alat=$_POST['nama_alat'];
      $deskripsi=$_POST['deskripsi'];
      $input_data=mysql_query("insert into alat value('','".$nama_alat."','".$gambar."','".$deskripsi."',NULL,NULL,'member')");
      if($input_data){
        echo "<meta http-equiv='refresh' content='0; url=update_studio.php'>";
      }else{
        echo "<script>alert('data gagal disimpan !');</script>";
        echo "<meta http-equiv='refresh' content='0; url=update_studio.php'>";
      }
    }
  }

?>

<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="asset/icon.png"/>
	<title>Manage Our Music Studio !</title>

	<meta name="viewport" content="width=device-width , user-scalable=no">

	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/escape.css">
      <script type="text/javascript" src="http://js.nicedit.com/nicEdit-latest.js"></script>
    <script type="text/javascript">

        bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
  

    function enable_update(){
          if(update_harga.harga.disabled==true){
              update_harga.harga.disabled=false;
              update_harga.gitar.disabled=false;
              update_harga.bass.disabled=false;
              update_harga.drum.disabled=false;
        }else{
          update_harga.harga.disabled=true;
              update_harga.gitar.disabled=true;
              update_harga.bass.disabled=true;
              update_harga.drum.disabled=true;
        }
        }
  </script>
	
</head>
<body>
<br>
<div class="container">
	<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index.php"><img src="asset/logos.png" class="img-responsive" alt="Escape Studio" style="max-width: 65px; height: auto; "></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li ><a href="admin_dash.php">Dashboard <span class="sr-only">(current)</span></a></li>
        <li ><a href="studio_admin.php">Music Studio</a></li>
        <li class="active"><a href="update_studio.php">Update Studio</a></li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> <?php echo "".$_SESSION['ADM']; ?>
          <span class="caret"></span></a>
          <ul class="dropdown-menu" >
            <li><a href="logout.php">Logout</a></li> 
          </ul>
        </li
        
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="content">
 
    
      <div class="jumbotron" style="background: #eee url(asset/studio.png) no-repeat center; margin-top: 5%;">
        <div>
          <h1>Update Data Alat Music</h1>
          <p>Ini adalah halaman untuk melakukan update harga studio, dan update peralatan studio</p>
          <p>Terima Kasih #Owner</p>
          </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="posting">
              <form method="post" id="update_harga">

              <h3 style="text-align: center;"><b>UPDATE TARIF DAN DENDA</b></h3>
                  <div class="form-group">
                  <label>Biaya Sewa / shift studio Music :</label>
                  <input type="text" name="harga" id="harga" disabled value="<?php echo $harga_sewa; ?>" class="form-control">
                </div>

                <div class="form-group">
                  <label>Denda Kerusakan Gitar :</label>
                  <input type="number" name="gitar" id="gitar" disabled value="<?php echo $denda_gitar; ?>" class="form-control">
                </div>

                <div class="form-group">
                  <label>Denda Kerusakan Bass :</label>
                  <input type="number" name="bass" id="bass" disabled value="<?php echo $denda_bass; ?>" class="form-control">
                </div>

                <div class="form-group">
                  <label>Denda Kerusakan Drum :</label>
                  <input type="number" name="drum" id="drum" disabled value="<?php echo $denda_drum; ?>" class="form-control">
                </div>

                <input type="checkbox" id="check_update" onchange="enable_update();"> Update Tarif sewa dan Denda
                 <br>
                <br>
                <input type="submit" value="update tarif dan denda" class="btn btn-primary" 
                onclick="form.action='update_studio.php?action=harga';form.submit();">
              </form>
          </div>
        </div>

        <div class="col-md-6">
          <div class="posting">
              <form method="post" id="inventory" enctype="multipart/form-data">
                <h3 style="text-align: center;"><b>TAMBAH INVENTORY ALAT</b></h3>
                <div class="form-group">
                    <label>silahkan pilih gambar alat musik : </label>
                  <span class="btn btn-default btn-file">
                            Cari Gambar <input type="file" name="gambar" id="gambar" class="form-control"> 
                        </span>

                        <span>
                            <input type="submit" name="upload" id="upload" class="btn btn-success" value="upload"
                            onclick="form.action='update_studio.php?action=upload';form.submit();"> 
                        </span>

                </div>

                <p style="color: red;"><?php echo $peringatan; ?></p>

                <div class="form-group">
                  <label>Nama File Gambar : </label>
                  <input type="text" class="form-control" name="gambar_alat" value="<?php echo $nama_file; ?>" readonly>
                </div>

                <div class="form-group">
                  <label>Nama Alat Musik : </label>
                  <input type="text" class="form-control" name="nama_alat" required>
                </div>

                <div class="form-group">
                  <label>Deskripsi Alat Musik : </label>
                  <textarea id="deskripsi" name="deskripsi" style="width: 100%;"></textarea>
                </div>

                <input type="submit" value="simpan" class="btn btn-primary"
                onclick="form.action='update_studio.php?action=simpan';form.submit();">
                    
              </form>
          </div>
        </div>
      </div>
<br><br>
      <div class="row">
        <h4 style="text-align: center;"><b>BERIKUT INI ADALAH DATA INVENTARIS ALAT DI ESCAPE STUDIO MUSIC</b></h4>
        <?php 
        $data_inventaris=mysql_query("select * from alat where level='member'");
        $jumlah_alat=mysql_num_rows($data_inventaris);

         ?>
         <p>Jumlah peralatan yang dimiliki escape studio : <?php echo $jumlah_alat; ?></p><br>
         <div class="table-responsive">
          <table class="table table-striped table-condensed table-hover" align="center" style="text-align: center;">
          <tr style="background-color: #222; color: white;">
              <th style="text-align: center;">ID alat</th>
              <th style="text-align: center;">Nama Alat</th>
              <th style="text-align: center;">Nama File Gambar</th>
              <th style="text-align: center;">Aksi</th>

          </tr>
          <?php while($alat=mysql_fetch_array($data_inventaris)){ ?>
          <tr>
            <td><?php echo $alat['id']; ?></td>
            <td><?php echo $alat['nama']; ?></td>
            <td><?php echo $alat['gambar']; ?></td>
            <td>
              <a href="delete_inventory.php?id=<?php echo $alat['id']; ?>" onClick="return confirm('apakah anda yakin akan menghapus data ini ?')" class="btn btn-danger">Hapus Data</a>
            </td>
          </tr>
          <?php } ?>

          </table>
        </div>
      </div>
      
</div>


<div class="footer">
	<div class="container">
		&copy; Created by Danang  Aji Bimantoro
	</div>
</div>
	
</div>
	<script src="js/jquery2.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>

<?php
	}
?>