<?php
	session_start();
	session_unregister('USR','ADM');
	unset($USR,$ADM);
	$_SESSION=array();
	session_destroy();
	echo "<meta http-equiv='refresh' content='0; url=index.php' >";
?>