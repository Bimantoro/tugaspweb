<?php
  session_start();

  if(isset($_SESSION['USR'])){
    echo "<script>alert('maaf anda sudah login sebagai member')";
    echo "<meta http-equiv='refresh' content='0; url=member_home.php' >";
  }
  else if(isset($_SESSION['ADM'])){
    echo "<script>alert('maaf anda sudah login sebagai admin')";
    echo "<meta http-equiv='refresh' content='0; url=admin_dash.php' >";
  }
  else{
    
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="asset/icon.png"/>
	<title>Selamat datang di escape studio</title>
  <meta name="viewport" content="width=device-width , user-scalable=no">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/escape.css">
	
</head>
<body>
<br>
<div class="container">
	<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index.php"><img src="asset/logos.png" class="img-responsive" alt="Escape Studio" style="max-width: 65px; height: auto; "></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
        <li><a href="about.php">About Us</a></li>
      </ul>

      
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="content">


			<!-- / masukkan isi web disini -->
      <div class="container" style="padding: 10%; max-width: 700px;">
          <form role="form" action="#" method="POST">
            <div class="form-group">
                 <label>Admin ID:</label>
                  <input type="text" class="form-control" name="admin_id" required placeholder="masukkan Admin ID">
            </div>
             <div class="form-group">
               <label>Password:</label>
               <input type="password" class="form-control" name="pass_id" required placeholder="masukkan password">
               <br>

               <?php
                  include "konek_db.php";
                  if($_POST['admin_id']!=NULL or $_POST['pass_id']!=NULL){

                    $admin_id=$_POST['admin_id'];
                    $pass=$_POST['pass_id'];

                    $sql=mysql_query("select pass_id from admin where admin_id='".$admin_id."'");
                    $jml=mysql_num_rows($sql);
                    
                    if($jml==NULL){
                      //echo "<script>alert(' $admin_id belum terdaftar sebagai admin !');</script>";
                      //echo "<meta http-equiv='refresh' content='0; url=admin_login.php' >";
                      $alert = '';
                      $alert .= $admin_id." belum terdaftar sebagai admin !";
                    }else{

                      while($data=mysql_fetch_array($sql)) {
                            if($pass==$data['pass_id']){
                              session_register('ADM');
                              $_SESSION['ADM']=$admin_id;
                              echo "<meta http-equiv='refresh' content='0; url=admin_dash.php' >";
                            }else{
                              // echo "<script>alert('kombinasi admin_id dan password salah !');</script>";
                              $alert .= "Kombinasi Admin ID dan password salah !";
                              
                            } 
                       }
                    }
                     
                     echo '<p style="color: red;">'.$alert.'</p>';
                  }
                  
               ?>
               
            </div>
             <button type="submit" class="btn btn-primary btn-block" >Login</button>

            <button type="reset" class="btn btn-primary btn-block">Reset</button>

              </form>
              <br><br>
              

      </div>
	
</div>

<div class="footer">
  <div class="container">
    &copy; Created by Danang  Aji Bimantoro
  </div>
</div>

	
</div>



	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>


<?php
  }

?>