<?php
	include "konek_db.php";
	$id=$_POST['id'];
	$denda=$_POST['denda'];
	$sql=mysql_query("select biaya from penyewaan where id='".$id."'");
	$data=mysql_fetch_array($sql);
	$biaya=$data['biaya'];
	$total_bayar=$denda+$biaya;
	$sql=mysql_query("update penyewaan set denda='".$denda."', total_bayar='".$total_bayar."' where id='".$id."'");
	if($sql){
		echo "<meta http-equiv='refresh' content='0; url=studio_admin.php'>";
	}else{
		echo "<script>alert('gagal menambahkan denda'); </script>";
		echo "<meta http-equiv='refresh' content='0; url=studio_admin.php'>";

	}
 ?>