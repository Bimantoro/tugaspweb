<?php

$dbhost = "localhost"; //alamat server database
$dbuser = "studio"; //user server database
$dbpass = "studio"; //password server database
$dbname = "studio"; //nama database yang akan digunakan

$koneksi = mysql_connect($dbhost, $dbuser, $dbpass);
//$koneksi = mysql_connect("localhost", "root", "");

if(!$koneksi){
	echo "koneksi gagal<br>".mysql_error($koneksi);
	//menampilkan laporan kesalahan koneksi
}
else{
	mysql_select_db($dbname);
	//memilih database yang akan digunakan
	$query=mysql_query("delete from booking where datediff(current_date(), tgl_main) > 0;");
}
?>