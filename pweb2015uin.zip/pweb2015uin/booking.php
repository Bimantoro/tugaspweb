<?php
  session_start();
  include "konek_db.php";
  if(!session_is_registered('USR')){
    echo "<script>alert('Ooopss .. anda harus login terlebih dahulu');</script>";
    echo "<meta http-equiv='refresh' content='0; url=member_login.php' >";
  }
  if(!isset($_SESSION['USR'])){
    echo "<script>alert('Ooopss .. anda harus login terlebih dahulu');</script>";
    echo "<meta http-equiv='refresh' content='0; url=member_login.php' >";
  }else{


		                    	
	if(isset($_GET['action'])) {
		if($_GET['action']=='simpan'){
			$usr=$_POST['usr'];
			$nama=$_POST['nama'];
			$nomer_hp=$_POST['nomer'];
			$alamat=$_POST['alamat'];
			$tanggal_main=$_POST['date'];
			$tanggal_main=explode('/', $tanggal_main);
			$tanggal_main=$tanggal_main[2].'-'.$tanggal_main[1].'-'.$tanggal_main[0];
			$konfirmasi='belum';
			$shift=$_POST['shift'];

			$simpan_data=mysql_query("insert into booking value('','".$usr."','".$nama."','".$nomer_hp."','".$alamat."','".$tanggal_main."','".$shift."','".$konfirmasi."',CURRENT_TIMESTAMP);");
			if($simpan_data){
			echo "<meta http-equiv='refresh' content='0; url=cetak_bookingan.php'>";
			}else{
				echo "<script>alert('maaf sistem sedang mengalami gangguan'); </script>";
			}
		}
		if($_GET['action']=='tampil'){
		     $tgl=$_POST['date'];
		     $tgl=explode('/', $tgl);

		     $crn_date=date("Y-m-d");
		     $crn_date=explode('-', $crn_date);

		     if($tgl[2]<$crn_date[0]){
		     	$status=1;
		     }else{
		     	if($tgl[1]<$crn_date[1]){
		     		$status=1;
		     	}
		     	else{
		     		if($tgl[0]<$crn_date[2]){
		     			$status=1;
		     		}else{
		     			$status=0;
		     		}
		     	}
		     }


		     $tgl=$tgl[2].'-'.$tgl[1].'-'.$tgl[0];
		 }
	}
 ?>
<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" href="asset/icon.png"/>
	<title>Tempat booking studio Music</title>
  <meta name="viewport" content="width=device-width , user-scalable=no">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/escape.css">
	<link href="datepicker/css/jquery.datepick.css" rel="stylesheet">
	<script src="js/jquery2.js"></script>
	<script src="datepicker/js/jquery.plugin.js"></script>
  	<script src="datepicker/js/jquery.datepick.js"></script>        
    <script>
        $(function() {
          $('#tanggal').datepick();
        });

        function pilih_shift(shift){
        		form_booking.shift.value=shift;
        		form_booking.agreement.disabled=false;
        }

        function enable_submit(){
        	if(form_booking.submit_booking.disabled==true){
        	form_booking.submit_booking.disabled=false;
        }else{
        	form_booking.submit_booking.disabled=true;
        }
        }


    </script>
</head>
<body>
<br>
<div class="container">
	<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index.php"><img src="asset/logos.png" class="img-responsive" alt="Escape Studio" style="max-width: 65px; height: auto; "></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
        <li><a href="lihat_studio.php">Escape Music Studio</a></li>
        <li class="active"><a href="booking.php">Booking</a></li>
        <li><a href="cetak_bookingan.php">Status Pembookingan</a></li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> <?php echo "".$_SESSION['USR']; ?>
          <span class="caret"></span></a>
          <ul class="dropdown-menu" >
            <li><a href="logout.php">Logout</a></li> 
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="content">


			<!-- / masukkan isi web disini -->

			<div class="jumbotron" style="background: #eee; margin-top: 5%;">
  				<h1 style="text-align: center;">Formulir Booking Studio</h1>
  				<p style="text-align: center;">Silahkan isi Form Pembookingan dibawah ini !</p>
  					<form  method="post" id="form_booking">
  					
		  				<div class="form-group"> 
		                    <label>username :</label>
		                    <input type="text" class="form-control" name="usr" readonly value="<?php echo $_SESSION['USR'] ?>">
		                    <?php
		  						$sql=mysql_query("select * from member where username='".$_SESSION['USR']."'");
		  						
		  						$data=mysql_fetch_array($sql);
		  					 ?> 
		                  </div>
		                  <div class="form-group"> 
		                    <label>Nama :</label>
		                    <input type="text" class="form-control" name="nama" readonly value="<?php echo $data['nama']; ?>"> 
		                  </div>
		                  <div class="form-group"> 
		                    <label>No Hp :</label>
		                    <input type="text" class="form-control" name="nomer" readonly value="<?php echo $data['no_hp']; ?>"> 
		                  </div>
		                  <div class="form-group"> 
		                    <label>Alamat :</label>
		                    <input type="text" class="form-control" name="alamat" readonly value="<?php echo $data['alamat']; ?>"> 
		                  </div>
		                  
		                  <div class="form-group">
		                  	
		                  	<label>Tanggal Main :</label>
		                 
		                  	<div class="row">
		   						<div class="col-md-5">
		                  			<input class="form-control" type="text" name="date" required id="tanggal" style="200px;" value="<?php echo $_POST['date']; ?>">
		                  		</div>

		                  		<div class="col-md-7">
		                  		<input type="submit" value="cek ketersediaan tempat" style="width: 200px; margin: 0px" onclick="form.action='booking.php?action=tampil';form.submit();" class="btn btn-primary">
		                    	</div>
		                  	</div> 

		                    
		                  </div>
		                  
		                  <div class="form-group"> 
		                    <label>Shift :</label>
		                    <input type="text" class="form-control" name="shift" id="shift" required readonly>  
		                    <br>
		                    <div class="table-responsive">
					          <table class="table table-striped table-condensed table-hover" align="center" style="text-align: center;">
					          <tr style="background-color: #222; color: white;">
					              <th style="text-align: center;">Shift</th>
					              <th style="text-align: center;">Waktu Main (mulai)</th>
					              <th style="text-align: center;">Waktu Main (selesai)</th>
					              <th style="text-align: center;">Aksi</th>

					          </tr>

					          <?php if($_POST['date']==''){
					          	?>
					          	<tr><td colspan="4">Silahkan pilih tanggal main dulu !</td></tr>
					          	<?php
					          	}else if($status==1){
					          		?>
					          	<tr><td colspan="4" style="color: red;">Tanggal main kadaluarsa !</td></tr>
					          	<?php
					         
					          	}else{
					          
					          	$jam_mulai=8;	
					          	
					          for($index=1;$index<16;$index++) {
					          		
					           ?>
					          <tr>
					              <td><?php echo $index; ?></td>
					              <td><?php 
					              	if($jam_mulai<10){
					              echo "0"; echo $jam_mulai; echo ":00";
					              }else{
					              		echo $jam_mulai; echo ":00";
					              	} ?></td>

					              <td>
					              <?php 
					              	if($jam_mulai+1<10){
					              echo "0"; echo $jam_mulai+1; echo ":00";
					              }else{
					              		echo $jam_mulai+1; echo ":00";
					              	} ?>
					              </td>

					              <td>
					              		<?php 
					              		$temp=0;
					              		$coba=mysql_query("select * from booking where tgl_main='".$tgl."'");
					              		$jmdata=mysql_num_rows($coba);
					              		if($jmdata==0){
					              			?>
					              			<input type="button" value="Bisa dibooking" class="btn btn-success" onclick="pilih_shift(<?php echo $index; ?>)">
					              			<?php
					              		}else{
					              			while ($isi=mysql_fetch_array($coba)) {
					              		 	# code...
					              		 	if($index==$isi['shift']){
					              		 		$temp.=1;
					              		 	}
					              		 }
					              		 	if($temp==1){
					              		 		?>
					              		 		<input type="button" value="Sudah dibooking" class="btn btn-danger" disabled>
					              			 <?php		
					              		 	}else{
					              		 		?>

					              		 		<input type="button" value="Bisa dibooking" class="btn btn-success" onclick="pilih_shift(<?php echo $index; ?>)">
					              		 		<?php
					              		 	}
					              		 
					              		 } ?>
					              </td>
					          </tr>
					          <?php 
					          		$jam_mulai++;
					          }
					          } ?>
					          </table>
					        </div>
					        <div class="form-group" style="color: white; background-color: black; padding: 20px;">
					        <?php
					         $ambil_harga=mysql_query("select tarif_sewa_studio from alat where nama='studio'");
					         $data_ambil_harga=mysql_fetch_array($ambil_harga);

					         $denda=mysql_query("select denda from alat where nama='denda_gitar'");
					         $data_denda=mysql_fetch_array($denda);
					         $denda_gitar=$data_denda['denda'];

					         $denda=mysql_query("select denda from alat where nama='denda_bass'");
					         $data_denda=mysql_fetch_array($denda);
					         $denda_bass=$data_denda['denda'];

					         $denda=mysql_query("select denda from alat where nama='denda_drum'");
					         $data_denda=mysql_fetch_array($denda);
					         $denda_drum=$data_denda['denda'];
					         ?>
					        <p style="text-align: center;">syarat dan ketentuan booking studio ! </p>
					        				Setelah booking studio harus melakukan konfirmasi ke nomer : 08970745522 atau datang langsung ke Escape studio
					        				dan melakukan pembayaran DP, sebagai penanda bahwa pembooking serius untuk membooking studio
					        				jika setelah 1 hari setelah pembookingan online tidak melakukan konfirmasi, pembookingan dianggap batal
					        				<br>

					        				<br>
					        				Tarif/shift: <?php echo $data_ambil_harga['tarif_sewa_studio']; ?>
					        				<br>
					        				Denda kerusakan Gitar : <?php echo $denda_gitar; ?>
					        				<br>

					        				Denda kerusakan Bass : <?php echo $denda_bass; ?>
					        				<br>
					        				Denda kerusakan Drum : <?php echo $denda_drum; ?>
					        				<br>
					        				<br>
					        				maksimal keterlambatan 30 menit, jika 30 menit tidak datang maka pembookingan dibatalkan
					        				<br>
					        				<br>#terimakasih
					        </div>

					        <div class="form-group">
					        	<input type="checkbox" name="agreement" id="agreement" onchange="enable_submit()" disabled>  Saya Setuju
					        </div>

		                  </div>
		                  	<input type="submit" value="Booking Studio" class="btn btn-primary" disabled id="submit_booking" onclick="form.action='booking.php?action=simpan';form.submit();">
		                  	<a href="lihat_studio.php" class="btn btn-primary">Cancel</a>
  					</form>
  				
			</div>

	
</div>


<div class="footer">
	<div class="container">
		&copy; Created by Danang  Aji Bimantoro
	</div>
</div>
	
</div>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>

<?php
  }

?>