<?php
session_start();
include "konek_db.php";
if(isset($_SESSION['USR'])){
  echo "<script>alert('Maaf anda Sudah login sebagai member !');</script>";
  echo "<meta http-equiv='refresh' content='0; url=index.php' >";
}
else if(!isset($_SESSION['ADM'])){
  echo "<script>alert('Maaf anda harus Login sebagai Admin terlebih dahulu !');</script>";
  echo "<meta http-equiv='refresh' content='0; url=admin_login.php' >";
}else{

      $id=$_GET['id'];
      $sql=mysql_query("select * from penyewaan where id='".$id."'");
      $data=mysql_fetch_array($sql);
?>

<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="asset/icon.png"/>
	<title>Manage Our Music Studio !</title>

	<meta name="viewport" content="width=device-width , user-scalable=no">

	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/escape.css"> 

  <script type="text/javascript">
    function tambah_denda_gitar(x){
      var denda = parseInt(x);
      var total_denda=form_denda.denda.value;
      total_denda=parseInt(total_denda);
      total_denda=total_denda+denda;
      form_denda.denda.value=total_denda;
      form_denda.check_gitar.disabled=true;
    }

    function tambah_denda_bass(x){
      var denda = parseInt(x);
      var total_denda=form_denda.denda.value;
      total_denda=parseInt(total_denda);
      total_denda=total_denda+denda;
      form_denda.denda.value=total_denda;
      form_denda.check_bass.disabled=true;
    }

    function tambah_denda_drum(x){
      var denda = parseInt(x);
      var total_denda=form_denda.denda.value;
      total_denda=parseInt(total_denda);
      total_denda=total_denda+denda;
      form_denda.denda.value=total_denda;
      form_denda.check_drum.disabled=true;
    }

    function enable_checkbox(){
      form_denda.check_gitar.disabled=false;
      form_denda.check_bass.disabled=false;
      form_denda.check_drum.disabled=false;
    }
  </script>
	
</head>
<body onload="enable_checkbox();">
<br>
<div class="container">
	<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index.php"><img src="asset/logos.png" class="img-responsive" alt="Escape Studio" style="max-width: 65px; height: auto; "></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li ><a href="admin_dash.php">Dashboard <span class="sr-only">(current)</span></a></li>
        <li ><a href="studio_admin.php">Music Studio</a></li>
        <li class="active"><a href="tambah_denda.php">Tambah Denda</a></li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> <?php echo "".$_SESSION['ADM']; ?>
          <span class="caret"></span></a>
          <ul class="dropdown-menu" >
            <li><a href="logout.php">Logout</a></li> 
          </ul>
        </li
        
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="content">

      <div class="content">
      <form action="proses_tambah_denda.php" method="POST" id="form_denda">

            <h3 style="text-align: center;"><b>Form Tambah Denda</b></h3>

            <div class="row">
            <div class="col-md-6">
              <div class="posting">

                  <input type="hidden" class="form-control" name="id" readonly value="<?php echo $data['id']; ?>">
            
            <div class="form-group">
                <label>Nama :</label>
                  <input type="text" class="form-control" name="nama" readonly value="<?php echo $data['nama']; ?>">
            </div>
             <div class="form-group">
                  <label>Contact Person : </label>
                  <input type="text" name="nomer" class="form-control" readonly value="<?php echo $data['no_hp']; ?>">
            </div>

            <div class="form-group">
                  <label>Tanggal Main : </label>
                  <?php $tm=$data['tgl_main'];
                $tm=explode('-', $tm);
                $tm=$tm[2].'/'.$tm[1].'/'.$tm[0]; ?>
                  <input type="text" name="tanggal" class="form-control" readonly value="<?php echo $tm;; ?>">
            </div>
              </div>
              </div>

              <div class="col-md-6">
              <div class="posting">
              <div class="form-group">
                  <label>shift : </label>
                  <input type="text" name="shift" class="form-control" readonly value="<?php echo $data['shift']; ?>">
            </div>
             <div class="form-group">
                  <label>Alat Yang Rusak : </label>
                  <?php $denda=mysql_query("select denda from alat where nama='denda_gitar'");
                    $data_denda=mysql_fetch_array($denda);
                    $denda_gitar=$data_denda['denda'];


                    $denda=mysql_query("select denda from alat where nama='denda_bass'");
                    $data_denda=mysql_fetch_array($denda);
                    $denda_bass=$data_denda['denda'];

                    $denda=mysql_query("select denda from alat where nama='denda_drum'");
                    $data_denda=mysql_fetch_array($denda);
                    $denda_drum=$data_denda['denda'];
                   ?>
                   <input type="checkbox" id="check_gitar" value="<?php echo $denda_gitar ?>" onchange="tambah_denda_gitar(this.value);" disabled> Gitar 
                   <input type="checkbox" id="check_bass" value="<?php echo $denda_bass ?>" onchange="tambah_denda_bass(this.value);" disabled> Bass 
                   <input type="checkbox" id="check_drum" value="<?php echo $denda_drum ?>" onchange="tambah_denda_drum(this.value);" disabled> Drum 
                 
            </div>

            <div class="form-group">
                  <label>Denda : </label>
                  <input type="number" name="denda" class="form-control" readonly value="<?php echo $data['denda']; ?>" id="denda">
            </div>
                <button type="submit" class="btn btn-success" >Simpan</button>
                <a  href="studio_admin.php" class="btn btn-danger">Kembali</a>
              </div>

              </div>
            </div>
                 

            

             


              </form>
              </div>
</div>


<div class="footer">
	<div class="container">
		&copy; Created by Danang  Aji Bimantoro
	</div>
</div>
	
</div>
	<script src="js/jquery2.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>

<?php
	}
?>