<?php
include "konek_db.php";
$id=$_GET['id'];
$sql=mysql_query("select * from booking where id='".$id."'");
$data=mysql_fetch_array($sql);
$ambil_data=mysql_query("select tarif_sewa_studio from alat where nama='studio'");
$data_ambil_data=mysql_fetch_array($ambil_data);
$biaya=$data_ambil_data['tarif_sewa_studio'];
$denda=0;
$total_bayar=$biaya+$denda;
$query=mysql_query("insert into penyewaan value('','".$data['nama']."','".$data['no_hp']."','".$data['alamat']."','".$data['tgl_main']."','".$data['shift']."','".$biaya."','".$denda."','".$total_bayar."')");
if($query){
	echo "<meta http-equiv='refresh' content='0; url=studio_admin.php'>";
	$hapus=mysql_query("delete from booking where id='".$id."'");
}else{
	echo "<script>alert('Oppps, terjadi kesalahan !'); </script>";
	echo "<meta http-equiv='refresh' content='0; url=studio_admin.php'>";
}
 ?>
