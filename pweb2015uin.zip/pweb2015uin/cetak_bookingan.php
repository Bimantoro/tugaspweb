<?php
        session_start();
        include "konek_db.php";
        if(!isset($_SESSION['USR'])){
            echo "<script>alert('maaf, anda harus login terlebih dahulu sebagai member')";
            echo "<meta http-equiv='refresh' content='0; url=member_login.php' >";
          }else{


          
          ?>
<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="asset/icon.png"/>
  <title>Selamat datang status pembookingan escape studio music</title>

  <meta name="viewport" content="width=device-width , user-scalable=no">

  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/escape.css">
  
</head>
<body>
<br>
<div class="container">
  <nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index.php"><img src="asset/logos.png" class="img-responsive" alt="Escape Studio" style="max-width: 65px; height: auto; "></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
        <li><a href="lihat_studio.php">Escape Music Studio</a></li>
        <li><a href="booking.php">Booking</a></li>
        <li class="active"><a href="cetak_bookingan.php">Status Pembookingan</a></li>
      </ul>

          <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> <?php echo "".$_SESSION['USR']; ?>
          <span class="caret"></span></a>
          <ul class="dropdown-menu" >
            <li><a href="logout.php">Logout</a></li> 
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="content">


  <div class="row">
      <div class="col-md-12">
        <br>
          <h3 style="text-align: center;">Halaman Status Pembookingan</h3>
      </div>
  </div>

  <div>
  <?php  
    $sql=mysql_query("select * from booking where username='".$_SESSION['USR']."'");
    $jml=mysql_num_rows($sql);
    if($jml==NULL){
      ?>
      <div class="row">
      <div class="col-md-12">
        <br>
          <h3 style="text-align: center; color: red;">SAAT INI ANDA SEDANG TIDAK MELAKUKAN PEMBOOKINGAN !</h3>
      </div>
  </div>
      <?php
    }else{
      ?>

      <div>
        <div class="row"><div class="col-md-12"><label style="text-align: center;">Berikut ini adalah pembookingan yang anda lakukan :</label></div></div>
        <div class="table-responsive">
          <table class="table table-striped table-condensed table-hover" align="center" style="text-align: center;">
          <tr style="background-color: #222; color: white;">
              <th style="text-align: center;">Tanggal Main</th>
              <th style="text-align: center;">Shift</th>
              <th style="text-align: center;">Aksi</th>

          </tr>
          <?php while($isi=mysql_fetch_array($sql)) { ?>
          <tr>
              <td><?php echo $isi['tgl_main']; ?></td>
              <td><?php echo $isi['shift']; ?></td>
              <td align="center">
                <?php if($isi['konfirmasi']=='belum'){ ?>
                <a class="btn btn-primary btn-sm" href="#" disabled>sedang menunggu konfirmasi</a>
                <a class="btn btn-danger btn-sm" href="batal_booking_member.php?id=<?php echo $isi['id']; ?>" onClick="return confirm('apakah anda yakin akan membatalkan pembookingan ini ?')">batalkan booking</a>
                <?php }else{ ?>
                <a class="btn btn-success btn-sm" href="cetak_booking.php?id=<?php echo $isi['id']; ?>" target="_blank">Cetak Bukti Pembookingan</a>
                <?php } ?>
              </td>
          </tr>
          <?php } ?>
          </table>
        </div>
      </div>

      <?php
    }
    ?>
  </div>
  
</div>

  
</div>
<div class="footer">
  <div class="container">
    &copy; Created by Danang  Aji Bimantoro
  </div>
</div>

</div>



  <script src="js/jquery2.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>

<?php } ?>
