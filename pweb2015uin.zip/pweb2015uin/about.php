
<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="asset/icon.png"/> 
  <title>Selamat datang di escape studio</title>

  <meta name="viewport" content="width=device-width , user-scalable=no">

  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/escape.css">
  
</head>
<body>
<br>
<div class="container">
  <nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index.php"><img src="asset/logos.png" class="img-responsive" alt="Escape Studio" style="max-width: 65px; height: auto; "></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
        <li class="active"><a href="about.php">About Us</a></li>
      </ul>
      <?php
        session_start();

        if(isset($_SESSION['USR'])){
          ?>
          <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> <?php echo "".$_SESSION['USR']; ?>
          <span class="caret"></span></a>
          <ul class="dropdown-menu" >
            <li><a href="logout.php">Logout</a></li> 
          </ul>
        </li>
      </ul>
      <?php
        }
        else {
      ?>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="registrasi.php"><span class="glyphicon glyphicon-user"></span> Register</a></li>
        <li><a href="member_login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>
      <?php
    }
    ?>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="content">


      <!-- / masukkan isi web disini -->
      <div class="container"  style="margin-top: 10%; color: white;">
        <div class="jumbotron" style="background-color: #222;">
          <div class="container" align="center">
          <a href="index.php"><img src="asset/logos.png" class="img-responsive" alt="escape studio"></a>
          </div>
          <br>
          <marquee direction="up" height="400" onmouseout="this.start()" onmouseover="this.stop()" scrollamount="3">
          <p><span>Escape Studio adalah studio music ternama di daerah Yogyakarta, dan ini adalah website resmi dari Escape studio. Studio music ini berawal dari hobi owner yang suka bermain musik, kemudian dari hobi tersebut muncullah ide untuk membuat sebuah studio musik yang beralamatkan di Jl. Laksda Adisucipto Yogyakarta saat ini dalam studio musik ini baru menyediakan 1 buah studio band yang dapat digunakan, karena studio band yang satunya masih direnovasi sehingga belum dapat digunakan, Escape studo juga memberikan tutorial-tutorial yang dapat diakses melalui website resmi escape Studo sehingga anda dapat belajar musik kapanpun dan dimanapun melalui gadget anda, anda juga bisa membaca berita-berita terupdate tentang dunia musik, selain itu anda dapat mem-booking studio musik dari website resmi ini.</span></p>
          <p><span>Escape Studio berdiri sejak tahun 2010, pada saat itu hanya tersedia 1 studio band, dan sekarang sudah 2 studio band, awalnya Escape studio beralamatkan di Jl. Taman Siswa Yogyakarta, akan tetapi sejak tahun 2014 berpindah di Jl. Laksda Adisucipto Yogyakarta tepatnya didepan kampus UIN Sunan Kalijaga Yogyakarta.</span></p>
          <p><span>Untuk informasi lebih lanjut mengenai escape studio, anda dapat menghubungi contact dibawah ini : <br>
          <p style="text-align: center; "><strong>CP : 08970745522</strong></p>
          <p style="text-align: center;"><strong>Email : adjie6661@gmail.com</strong></p>
          <p style="text-align: center;"><strong>IG : @danang_abhe</strong></p>
          <p style="text-align: center;"><strong>facebook : <a href="https://www.facebook.com/danang.abhe" target="_blank">Danang Aji Bimantoro</a></strong></p>
          </span></p>
          </marquee>
          </div>
      </div>
        
      </div>

  
</div>
<div class="footer">
  <div class="container">
    &copy; Created by Danang  Aji Bimantoro
  </div>
</div>

</div>



  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>
