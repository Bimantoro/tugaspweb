<!DOCTYPE html>
<html>
<head>
	<title></title>
	
</head>
<body onload="window.print()">
<?php
	include "konek_db.php";
	$sql=mysql_query("select * from penyewaan");
 ?>
 <div align="center">
		<p style="text-align: center;">Ini adalah data penyewaan yang terjadi di escape studio : <br></p>
	</div>
 <div align="center">
 	 <table style="width: 100%;" align="center">
 	 <tr>
              <th style="text-align: center;">Nama</th>
              <th style="text-align: center;">Contact Person</th>
              <th style="text-align: center;">Tanggal Main</th>
              <th style="text-align: center;">Shift</th>
              <th style="text-align: center;">Biaya</th>
              <th style="text-align: center;">Denda</th>
              <th style="text-align: center;">Total Bayar</th>

	</tr>
	<?php
	$total_biaya=0;
	$total_denda=0;
	$total_total_bayar=0; 
	while($isi=mysql_fetch_array($sql)){
		$tm=$isi['tgl_main'];
                $tm=explode('-', $tm);
                $tm=$tm[2].'/'.$tm[1].'/'.$tm[0];
	 ?>
	<tr>
            <td style="text-align: center;"><?php echo $isi['nama']; ?></td>
            <td style="text-align: center;"><?php echo $isi['no_hp']; ?></td>
            <td style="text-align: center;"><?php echo $tm; ?></td>
            <td style="text-align: center;"><?php echo $isi['shift']; ?></td>
            <td style="text-align: center;"><?php echo $isi['biaya']; $total_biaya=$total_biaya+$isi['biaya']; ?></td>
            <td style="text-align: center;"><?php echo $isi['denda']; $total_denda=$total_denda+$isi['denda'];?></td>
            <td style="text-align: center;"><?php echo $isi['total_bayar']; $total_total_bayar=$total_total_bayar+$isi['total_bayar'];?></td>
	</tr>
	<?php } ?>

	 </table>

 </div>
 <br>
 <hr>
 <br>
 <p>Pemasukan dari sewa : <?php echo $total_biaya; ?></p>
	 <p>Pemasukan dari denda : <?php echo $total_denda; ?></p>
	 <p>Pemasukan Keseluruhan : <?php echo $total_total_bayar; ?></p>

</body>
</html>