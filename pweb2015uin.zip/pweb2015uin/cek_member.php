<?php

	session_start();

	$member=$_POST['member_id'];
	$pass=$_POST['pass_id'];

	if($member=='danang' && $pass=='danang'){
		session_register('USR');

		$_SESSION['USR']=$member;

		echo "<meta http-equiv='refresh' content='0; url=member_home.php' >";
	}

	else{
		//echo "<meta http-equiv='refresh' content='0; url=member_login.php' >";
		echo "nama = ".$member;
		echo "pass = ".$pass;
	}
?>