<?php
include "konek_db.php";
$sql=mysql_query("delete from alat where id='".$_GET['id']."';");
echo "<meta http-equiv='refresh' content='0; url=update_studio.php' >";

?>