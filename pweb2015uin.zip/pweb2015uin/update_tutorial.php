<?php
session_start();

if(isset($_SESSION['USR'])){
  echo "<script>alert('Maaf anda Sudah login sebagai member !');</script>";
  echo "<meta http-equiv='refresh' content='0; url=index.php' >";
}
else if(!isset($_SESSION['ADM'])){
  echo "<script>alert('Maaf anda harus Login sebagai Admin terlebih dahulu !');</script>";
  echo "<meta http-equiv='refresh' content='0; url=admin_login.php' >";
}else{

?>

<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="asset/icon.png"/>
	<title>Manage Our Tutorials !</title>

	<meta name="viewport" content="width=device-width , user-scalable=no">

	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/escape.css">

    <script type="text/javascript" src="http://js.nicedit.com/nicEdit-latest.js"></script>
    <script type="text/javascript">
//<![CDATA[
        bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
  //]]>
  </script> 
	
</head>
<body>
<br>
<div class="container">
	<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index.php"><img src="asset/logos.png" class="img-responsive" alt="Escape Studio" style="max-width: 65px; height: auto; "></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li ><a href="admin_dash.php">Dashboard <span class="sr-only">(current)</span></a></li>
        <li ><a href="manage_school.php">Music School</a></li>
        <li class="active"><a href="update_tutorial.php">update Music School</a></li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> <?php echo "".$_SESSION['ADM']; ?>
          <span class="caret"></span></a>
          <ul class="dropdown-menu" >
            <li><a href="logout.php">Logout</a></li> 
          </ul>
        </li
        
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="content">
 
    
      <div class="jumbotron" style="background: #ff7878  url(asset/schools_pink.png) no-repeat center; margin-top: 5%;">
        <div>
          <h1>Update Konten Music School</h1>
          <p>Konten Music Schools berisi tutorial-tutorial bermain musik,
           jadi sangat diharapkan admin memposting tutorial-tutorial music disini,
            dan jika ingin memposting berita harap di posting di konten music news </p>
          <p>Terima Kasih #Owner</p>
          </div>
      </div>
      <?php
      include "konek_db.php";
      if($_POST['judul']!=''){
        $query=mysql_query("update tutorial tutorial set judul='".$_POST['judul']."', isi='".$_POST['konten']."', admin='".$_SESSION['ADM']."',created=CURRENT_TIMESTAMP where id='".$_GET['id']."'");
        if($query){
          echo "<meta http-equiv='refresh' content='0; url=manage_school.php'>";
        }else{
          echo "<script>alert('maaf terjadi kesalahan saat melakukan update !'); </script>";
          echo "<meta http-equiv='refresh' content='0; url=manage_school.php'>";

        }
      }else{
      
      $sql=mysql_query("select * from tutorial where id='".$_GET['id']."'");
      if(mysql_num_rows($sql)==0){
        echo "<meta http-equiv='refresh' content='0; url=manage_school.php'>";
      }else{

        $data=mysql_fetch_array($sql);
      }
    }
       ?>
      
      
      <div class="posting">
      <form role="form" action="#" method="POST">
            <div class="form-group">

                 <label>Judul Tutorial : <span style="color: red;">*</span></label>
                  <input type="text" class="form-control" name="judul" required placeholder="masukkan judul news disini" value="<?php echo $data['judul'];?>">
            </div>
             <div class="form-group">

                  <label>Konten Tutorial : <span style="color: red;">*</span></label>
                  <textarea name="konten" style="width: 100%;" id="editor1"><?php echo $data['isi']; ?></textarea>
                  

            </div>

             <button type="submit" class="btn btn-success" >update</button>
             <a  href="manage_school.php" class="btn btn-danger">Kembali</a>


              </form>
              </div>
</div>


<div class="footer">
	<div class="container">
		&copy; Created by Danang  Aji Bimantoro
	</div>
</div>
	
</div>
	<script src="js/jquery2.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>

<?php
}
?>