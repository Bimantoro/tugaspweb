<?php
session_start();

if(isset($_SESSION['USR'])){
  echo "<script>alert('Maaf anda Sudah login sebagai member !');</script>";
  echo "<meta http-equiv='refresh' content='0; url=index.php' >";
}
else if(!isset($_SESSION['ADM'])){
  echo "<script>alert('Maaf anda harus Login sebagai Admin terlebih dahulu !');</script>";
  echo "<meta http-equiv='refresh' content='0; url=admin_login.php' >";
}else{

?>

<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="asset/icon.png"/>
	<title>Manage Our Free News !</title>

	<meta name="viewport" content="width=device-width , user-scalable=no">

	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/escape.css">
	
</head>
<body>
<br>
<div class="container">
	<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index.php"><img src="asset/logos.png" class="img-responsive" alt="Escape Studio" style="max-width: 65px; height: auto; "></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li ><a href="admin_dash.php">Dashboard <span class="sr-only">(current)</span></a></li>
        <li class="active"><a href="manage_news.php">News</a></li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> <?php echo "".$_SESSION['ADM']; ?>
          <span class="caret"></span></a>
          <ul class="dropdown-menu" >
            <li><a href="logout.php">Logout</a></li> 
          </ul>
        </li
        
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="content">
 
      <?php
        include "konek_db.php";
        $peringatan='';
        $sql=mysql_query("select * from news ORDER BY created DESC;");
        $jmlh=mysql_num_rows($sql);

      ?>
      <div class="jumbotron" style="background: #eee url(asset/news.png) no-repeat center; margin-top: 5%;">
        <div>
          <h1>Management Konten News</h1>
          <p>Dalam konten News hanya berisi berita-berita music, tidak berisi tutorial. Jadi sebagai admin harus mem-posting yang berkaitan dengan berita-berita music, dan tidak boleh ada unsur pronografi dan unsur-unsur yang berbau SARA</p>
          <p>Terima kasih #Owner</p>
          </div>
      </div>
      <br>
      <p>JUMLAH POST UNTUK KONTEN NEWS : <?php echo "".$jmlh; ?></p>
      <?php
      if($jmlh==NULL){
        ?>

          <br><br>
          <h4 style="text-align: center; text-decoration: bold; color: red;">TIDAK ADA POST YANG TERSEDIA !</h4>


      <?php
      }else{
        ?>
        <div class="table-responsive">
          <table class="table table-striped table-condensed table-hover" align="center" style="text-align: center;">
          <tr style="background-color: #222; color: white;">
              <th style="text-align: center; max-width: 600px;">Judul News</th>
              <th style="text-align: center;">Tanggal Post</th>
              <th style="text-align: center;">Admin</th>
              <th style="text-align: center;">Manage</th>
          </tr>
          <?php while($isi=mysql_fetch_array($sql)) { ?>
          <tr>
              <td><?php echo $isi['judul']; ?></td>
              <td><?php echo $isi['created']; ?></td>
              <td><?php echo $isi['admin']; ?></td>
              <td align="center">
                <a class="btn btn-success btn-sm" href="update_news.php?id=<?php echo $isi['id']; ?>">Update</a>
                <a class="btn btn-danger btn-sm" href="delete_news.php?id=<?php echo $isi['id']; ?>">Delete</a>
              </td>
          </tr>
          <?php } ?>
          </table>
        </div>

     <?php   
      }
      ?>
      <br><br>
      <div align="right">
        <a class="btn btn-primary" href="buat_news.php">Buat Post</a>
      </div>
      

	
</div>


<div class="footer">
	<div class="container">
		&copy; Created by Danang  Aji Bimantoro
	</div>
</div>
	
</div>
	<script src="js/jquery2.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>

<?php
	}
?>