<?php
session_start();

if(isset($_SESSION['USR'])){
  echo "<script>alert('Maaf anda Sudah login sebagai member !');</script>";
  echo "<meta http-equiv='refresh' content='0; url=index.php' >";
}
else if(!isset($_SESSION['ADM'])){
  echo "<script>alert('Maaf anda harus Login sebagai Admin terlebih dahulu !');</script>";
  echo "<meta http-equiv='refresh' content='0; url=admin_login.php' >";
}else{

?>

<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="asset/icon.png"/>
	<title>Manage Our Free News !</title>

	<meta name="viewport" content="width=device-width , user-scalable=no">

	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/escape.css">
  <script type="text/javascript" src="ckeditor/ckeditor.js"></script>
  <!--  <script type="text/javascript" src="http://js.nicedit.com/nicEdit-latest.js"></script>
    <script type="text/javascript">
//<![CDATA[
        bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
  //]]>
  </script> !-->
	
</head>
<body>
<br>
<div class="container">
	<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index.php"><img src="asset/logos.png" class="img-responsive" alt="Escape Studio" style="max-width: 65px; height: auto; "></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li ><a href="admin_dash.php">Dashboard <span class="sr-only">(current)</span></a></li>
        <li ><a href="manage_news.php">News</a></li>
        <li class="active"><a href="buat_news.php">Post News</a></li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> <?php echo "".$_SESSION['ADM']; ?>
          <span class="caret"></span></a>
          <ul class="dropdown-menu" >
            <li><a href="logout.php">Logout</a></li> 
          </ul>
        </li
        
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="content">
 
    
      <div class="jumbotron" style="background: #fff000 url(asset/news_yellow.png) no-repeat center; margin-top: 5%;">
        <div>
          <h1>Menambah Konten News</h1>
          <p>Perlu mengingatkan lagi, bahwa dalam konten news ini hanya berisi berita-berita musik, sedangkan untuk tutorial-tutorial akan diletakkan di music school, sehingga dimohon admin mem-post hal-hal yang berkaitan dengan berita-berita dari dunia musik</p>
          <p>Terima Kasih #Owner</p>
          </div>
      </div>

      <?php 
      if($_POST['judul']!=''){


      include "konek_db.php";
      $judul=$_POST['judul'];
      $konten=$_POST['konten'];
      $admin=$_SESSION['ADM'];
      $qeury=mysql_query("select * from news;");
      $jml=mysql_num_rows($qeury);

      $sql=mysql_query("insert into news  value('','".$judul."','".$konten."','".$admin."',CURRENT_TIMESTAMP);");
      if(!$sql){
      }else{
        echo "<meta http-equiv='refresh' content='0; url=manage_news.php' >";
      }
}

       ?>

      <div class="posting">
      <form action="#" method="POST">
            <div class="form-group">

                 <label>Judul News : <span style="color: red;">*</span></label>
                  <input type="text" class="form-control" name="judul" required placeholder="masukkan judul news disini">
            </div>
             <div class="form-group">

                  <label>Konten News : <span style="color: red;">*</span></label>
                  <textarea name="konten" style="width: 100%;" id="editor1"></textarea>
                  <script type="text/javascript">
                  CKEDITOR.replace('editor1');
              </script>

            </div>

             <button type="submit" class="btn btn-success" >Simpan</button>
             <a  href="manage_news.php" class="btn btn-danger">Kembali</a>


              </form>
              </div>
</div>


<div class="footer">
	<div class="container">
		&copy; Created by Danang  Aji Bimantoro
	</div>
</div>
	
</div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>

<?php
	}
?>