<?php
include "konek_db.php";
$sql=mysql_query("update member set konfirmasi='sudah' where id='".$_GET['id']."';");
echo "<meta http-equiv='refresh' content='0; url=manage_member.php' >";

?>