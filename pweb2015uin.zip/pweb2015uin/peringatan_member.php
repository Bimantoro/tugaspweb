<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="asset/icon.png"/>
	<title>Selamat datang di escape studio</title>
  <meta name="viewport" content="width=device-width , user-scalable=no">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/escape.css">
	
</head>
<body>
<br>
<div class="container">
	<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index.php"><img src="asset/logos.png" class="img-responsive" alt="Escape Studio" style="max-width: 65px; height: auto; "></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
        <li><a href="#">About Us</a></li>
      </ul>

      
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="content">


			<!-- / masukkan isi web disini -->
      <div class="container" style="padding: 10%; max-width: 700px;" align="center">
      <label style="color: red;">Ops...<br>
        Untuk mengakses Konten ini anda harus Login sebagai member terlebih dahulu.
      </label>
      <br>
      
      <br>
      Anda sudah terdaftar sebagai member ? Silahkan klik dibawah ini
      <br>
      <a href="member_login.php"><button class="btn btn-primary btn-block" href="member_login.php">Login</button></a>
      <br>
      <br>
      
      <br>
      Anda <strong>BELUM</strong> terdaftar sebagai member ? Silahkan klik dibawah ini
      <br>
      <a href="registrasi.php"><button class="btn btn-primary btn-block">Register</button></a>


      </div>
	
</div>
	
</div>

<div class="footer">
  <div class="container">
    &copy; Created by Danang  Aji Bimantoro
  </div>
</div>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>