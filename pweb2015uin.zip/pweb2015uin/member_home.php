<?php
  session_start();

  if(!session_is_registered('USR')){
    echo "<script>alert('Ooopss .. anda harus login terlebih dahulu');</script>";
    echo "<meta http-equiv='refresh' content='0; url=index.php' >";
  }
  if(!isset($_SESSION['USR'])){
    echo "<script>alert('Ooopss .. anda harus login terlebih dahulu');</script>";
    echo "<meta http-equiv='refresh' content='0; url=index.php' >";
  }else{

?>
<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="asset/icon.png"/>
	<title>Selamat datang di escape studio</title>
  <meta name="viewport" content="width=device-width , user-scalable=no">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/escape.css">
	
</head>
<body>
<br>
<div class="container">
	<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

      <a class="navbar-brand" href="index.php"><img src="asset/logos.png" class="img-responsive" alt="Escape Studio" style="max-width: 65px; height: auto; "></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
        <li><a href="about.php">About Us</a></li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> <?php echo "".$_SESSION['USR']; ?>
          <span class="caret"></span></a>
          <ul class="dropdown-menu" >
            <li><a href="logout.php">Logout</a></li> 
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="content">


			<!-- / masukkan isi web disini -->
			<div class="jumbotron" style="background: #222 url() no-repeat center ; color: white; margin-top: 10%;">
				
  				<h1><marquee>Selamat Datang di Escape Studio</marquee></h1>
  				<p>Escape Studio adalah studio music ternama di daerah Yogyakarta, dan ini adalah website resmi dari Escape studio. Mau tau selengkapnya tentang Escape Studio ?</p>
  				<p align="right"><a class="btn btn-primary btn-lg" href="about.php" role="button" >About Escape</a></p>
  			
			</div>

			<div class="jumbotron" style="background: #eee url(asset/news.png) no-repeat center;">
  				<h1>Music News</h1>
  				<p>Escape Studio memberikan berita-berita terbaru yang dapat anda akses kapanpun dan dimanapun tanpa ada batasan, berita-berita tentang music akan selalu di update</p>
  				<p align="right"><a class="btn btn-success btn-lg" href="news.php" role="button" >Music News</a></p>
			</div>
			<div class="jumbotron" style="background: #eee url(asset/studio.png) no-repeat center;">
  				<h1>Music Studio</h1>
  				<p>Saat ini anda dapat melakukan pemesanan/booking studio musik langsung dari gadget anda</p>
  				<p align="right"><a class="btn btn-success btn-lg" href="lihat_studio.php" role="button" >Music Studio</a></p>
			</div>

			<div class="jumbotron" style="background: #eee url(asset/school.png) no-repeat center;">
  				<h1>Music School</h1>
  				<p>Belajar musik semakin mudah dari gadget anda, Escape studio memberikan layanan kepada anda berupa tutorial-tutorial dalam bermain musik</p>
  				<p align="right"><a class="btn btn-success btn-lg" href="schools.php" role="button" >Music School</a></p>
			</div>

	
</div>


<div class="footer">
	<div class="container">
		&copy; Created by Danang  Aji Bimantoro
	</div>
</div>
	
</div>
	<script src="js/jquery2.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>

<?php
  }

?>